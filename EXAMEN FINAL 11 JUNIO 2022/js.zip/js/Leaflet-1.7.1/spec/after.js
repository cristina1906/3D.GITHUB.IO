L.Icon.Default.imagePath = '/base/dist/images/';
